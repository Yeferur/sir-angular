// backend/server.js
const path = require('path');
const dotenv = require('dotenv');

// PM2 puede iniciar sir-api con el cwd en la raíz del repositorio. Cargamos
// siempre la configuración propia del backend antes de calcular CORS, IA y
// cualquier otro flag; el archivo legado sólo completa variables ausentes.
dotenv.config({ path: path.join(__dirname, '.env') });
dotenv.config({ path: path.join(__dirname, 'env', '.env') });

const express = require('express');
const cors = require('cors');
const http = require('http');

const app = express();
// Nginx se conecta desde loopback; así req.ip conserva el cliente real sin
// confiar cabeceras X-Forwarded-For enviadas directamente desde Internet.
app.set('trust proxy', 'loopback');
const aiEnabled = ['1', 'true', 'yes', 'on'].includes(String(process.env.IA_ENABLED ?? process.env.AI_ENABLED ?? '').trim().toLowerCase());

function parseOrigins(value) {
  return String(value || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);
}

const allowedOrigins = parseOrigins(process.env.CORS_ORIGIN || process.env.FRONTEND_URL);
const isProduction = process.env.NODE_ENV === 'production';
const corsOptions = {
  origin(origin, callback) {
    if (!origin) return callback(null, true);
    if (!isProduction) return callback(null, true);
    if (allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origen no permitido por CORS'));
  },
  credentials: true,
};

// ✅ Expose uploads folder as static (for profile photos, etc.)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Compatibilidad: avatares antiguos pudieron quedar en /uploads o /uploads/usuarios.
app.get('/uploads/fotos_perfil/:filename', (req, res, next) => {
  const safeName = path.basename(req.params.filename || '');
  if (!safeName) return next();

  const candidates = [
    path.join(__dirname, 'uploads', 'fotos_perfil', safeName),
    path.join(__dirname, 'uploads', 'usuarios', safeName),
    path.join(__dirname, 'uploads', safeName),
  ];

  for (const filePath of candidates) {
    if (require('fs').existsSync(filePath)) {
      return res.sendFile(filePath);
    }
  }

  return next();
});

const loginRoutes = require('./routes/Login/login.routes');
const inicioRoutes = require('./routes/inicio.routes');
const reservasRoutes = require('./routes/Reservas/reserva.routes');
const puntosRoutes = require('./routes/Puntos/puntos.routes');
const programacionRoutes = require('./routes/Programacion/programacion.routes');
const sesionesRoutes = require('./routes/Usuarios/usuarios.routes');
const toursRoutes = require('./routes/Tours/tours.routes');
const transfersRoutes = require('./routes/Transfers/transfers.routes');
const historialNewRoutes = require('./routes/Historial/historial.routes');
const permisosRoutes = require('./routes/Permisos/permisos.routes');
const searchRoutes = require('./routes/Search/search.routes');
const homeRoutes = require('./routes/Home/home.routes');
const turnosRoutes = require('./routes/Turnos/turnos.routes');
const notificacionesRoutes = require('./routes/Notificaciones/notificaciones.routes');
const { iniciarVencimientosJob, detenerVencimientosJob } = require('./jobs/vencimientos.job');
const { iniciarEmailOutboxJob, detenerEmailOutboxJob } = require('./jobs/email-outbox.job');

app.use(cors(corsOptions));
app.use(express.json({ limit: process.env.JSON_LIMIT || '10mb' }));
app.use(express.urlencoded({ extended: true, limit: process.env.URLENCODED_LIMIT || '10mb' }));

app.use('/api', loginRoutes);
app.use('/api', inicioRoutes);
app.use('/api', reservasRoutes);
app.use('/api', puntosRoutes);
app.use('/api', programacionRoutes);
app.use('/api', sesionesRoutes);
app.use('/api', transfersRoutes);
app.use('/api/tours', toursRoutes);
app.use('/api/historial', historialNewRoutes);
app.use('/api', permisosRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/home', homeRoutes);
app.use('/api/turnos', turnosRoutes);
app.use('/api/notificaciones', notificacionesRoutes);
const dashboardRoutes = require('./routes/Dashboard/dashboard.routes');
app.use('/api/dashboard', dashboardRoutes);

const confirmacionRoutes = require('./routes/Confirmacion/confirmacion.routes');
app.use('/api/confirmacion', confirmacionRoutes);

const comisionesRoutes = require('./routes/Comisiones/comisiones.routes');
app.use('/api/comisiones', comisionesRoutes);

const segurosRoutes = require('./routes/Seguros/seguros.routes');
app.use('/api/seguros', segurosRoutes);

// ✅ Crear server HTTP (para compartir con WS)
const DEFAULT_PORT = Number(process.env.PORT || 4000);
const isDevelopment = process.env.NODE_ENV !== 'production';
const server = http.createServer(app);

// ✅ Iniciar WS sobre el mismo servidor HTTP: ws://host:puerto/ws
const { initWebSocket } = require('./websocket');
initWebSocket(server);

let activePort = DEFAULT_PORT;

function startServer(port) {
  activePort = port;
  server.listen(port, () => {
    console.log(`✅ Backend HTTP corriendo en http://localhost:${activePort}`);
    console.log(`✅ WS corriendo en ws://localhost:${activePort}/ws`);
  });
}

// Después de las otras rutas, antes de startServer()
if (aiEnabled) {
  const iaRoutes = require('./routes/IA/ia.routes');
  app.use('/api/ia', iaRoutes);
} else {
  app.use('/api/ia', (_req, res) => {
    return res.status(503).json({
      success: false,
      message: 'La función de IA no está disponible temporalmente.',
    });
  });
}

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    if (isDevelopment && activePort === DEFAULT_PORT) {
      const fallbackPort = DEFAULT_PORT + 1;
      console.warn(
        `⚠️ Puerto ${DEFAULT_PORT} en uso. Reintentando automaticamente en ${fallbackPort} (modo desarrollo).`
      );
      startServer(fallbackPort);
      return;
    }

    console.error(`❌ Puerto ${activePort} en uso. Cierra el proceso previo o cambia PORT en .env.`);
    process.exit(1);
  }

  console.error('❌ Error iniciando el servidor:', err);
  process.exit(1);
});

// ✅ Levantar server
iniciarVencimientosJob();
iniciarEmailOutboxJob();
startServer(DEFAULT_PORT);

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[shutdown] ${signal}: cerrando sir-api de forma ordenada.`);
  detenerVencimientosJob();

  const closeServer = new Promise((resolve) => {
    if (!server.listening) return resolve();
    server.close(() => resolve());
  });
  const forceExit = setTimeout(() => {
    console.error('[shutdown] Tiempo de cierre agotado; finalizando sir-api.');
    process.exit(1);
  }, 15000);

  await Promise.allSettled([closeServer, detenerEmailOutboxJob({ timeoutMs: 12000 })]);
  clearTimeout(forceExit);
  process.exit(0);
}

process.once('SIGTERM', () => { void shutdown('SIGTERM'); });
process.once('SIGINT', () => { void shutdown('SIGINT'); });
