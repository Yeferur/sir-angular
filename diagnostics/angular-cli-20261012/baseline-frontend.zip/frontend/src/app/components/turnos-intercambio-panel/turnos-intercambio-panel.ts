import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SirDrawerService } from '../../services/Drawer/drawer.service';
import { AsesorIntercambio, TurnoDia, TurnosService } from '../../services/Turnos/turnos.service';
import { SirAlertService } from '../../services/Alertas/alert.service';
import { SirSelectComponent, SirSelectOption, compareSelectValuesAsStrings } from '../../shared/select/select';

@Component({selector:'app-turnos-intercambio-panel',standalone:true,imports:[CommonModule,FormsModule,SirSelectComponent],template:`
  <header class="head"><div><span class="eyebrow">Cambio puntual</span><h2>Intercambiar turno</h2><p>{{ day.nombreDia }} {{ dateLabel(day.fecha) }}</p></div><button type="button" (click)="close()"><i class="bx bx-x"></i></button></header>
  <div class="body"><div class="current"><small>Tu jornada actual</small><strong>{{ time(day.horaInicio) }}–{{ time(day.horaFin) }}</strong></div>
    <label for="turnos-intercambio-companero">Compañero del mismo canal<app-select inputId="turnos-intercambio-companero" [(ngModel)]="selected" [options]="asesorSelectOptions()" [compareWith]="compareSelectValues" placeholder="Selecciona un asesor" /></label>
    @if(!loading()&&!candidates().length){<div class="empty">No hay jornadas diferentes disponibles para intercambiar ese día.</div>}
    <label>Motivo <span>opcional</span><textarea [(ngModel)]="reason" maxlength="300" rows="4" placeholder="Cuéntale brevemente por qué necesitas el cambio"></textarea></label>
    <aside>El horario solo cambiará cuando el compañero acepte. La solicitud no modifica el resto de la semana.</aside></div>
  <footer><button class="secondary" type="button" (click)="close()">Cancelar</button><button class="primary" type="button" [disabled]="!selected||sending()" (click)="submit()">Enviar solicitud</button></footer>`,styles:[`
  :host{display:flex;flex-direction:column;height:100%;background:var(--bg-secondary);color:var(--text-primary)}.head{display:flex;justify-content:space-between;padding:24px;border-bottom:1px solid var(--border-color)}.head h2{margin:5px 0;font-size:24px}.head p{margin:0;color:var(--text-secondary)}.head button{width:36px;height:36px;border:1px solid var(--border-color);border-radius:var(--radius-md);background:var(--bg-tertiary);color:var(--text-primary);font-size:20px}.eyebrow{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--text-muted)}.body{flex:1;overflow:auto;padding:24px;display:grid;align-content:start;gap:22px}.current{display:flex;justify-content:space-between;padding:16px;border:1px solid var(--border-color);border-radius:var(--radius-lg);background:var(--bg-tertiary)}.current small,label span{color:var(--text-secondary)}label{display:grid;gap:8px;font-size:13px;font-weight:650}textarea{width:100%;border:1px solid var(--border-color);border-radius:var(--radius-md);background:var(--input-bg,var(--bg-tertiary));color:var(--text-primary);padding:12px;font:inherit}textarea{resize:vertical}aside,.empty{padding:14px;border-radius:var(--radius-md);background:color-mix(in srgb,var(--accent-blue) 8%,var(--bg-tertiary));color:var(--text-secondary);font-size:13px;line-height:1.5}footer{display:flex;justify-content:flex-end;gap:9px;padding:16px 24px;border-top:1px solid var(--border-color)}footer button{min-height:42px;padding:0 18px;border-radius:var(--radius-md);font-weight:650}.secondary{border:1px solid var(--border-color);background:transparent;color:var(--text-primary)}.primary{border:1px solid var(--accent-blue);background:var(--accent-blue);color:#fff}.primary:disabled{opacity:.5}
`]} )
export class TurnosIntercambioPanelComponent implements OnInit{
 private drawer=inject(SirDrawerService);private turnos=inject(TurnosService);private alerts=inject(SirAlertService);
 day!:TurnoDia;readonly candidates=signal<AsesorIntercambio[]>([]);readonly loading=signal(true);readonly sending=signal(false);selected='';reason='';
 readonly compareSelectValues = compareSelectValuesAsStrings;
 readonly asesorSelectOptions = computed<SirSelectOption[]>(() => [
  { value: '', label: 'Selecciona un asesor' },
  ...this.candidates().map(a => ({
   value: String(a.idUsuario),
   label: `${a.nombre ?? ''} · ${this.time(a.horaInicio)}–${this.time(a.horaFin)}`,
  })),
 ]);
 ngOnInit(){const props=this.drawer.drawer()?.props||{};this.day=props['day'];const candidates=(props['candidates']||[]) as AsesorIntercambio[];if(!this.day||!candidates.length){this.drawer.close(true);return;}this.candidates.set(candidates);this.loading.set(false);}
 close(){this.drawer.close();}submit(){if(!this.selected)return;this.sending.set(true);this.turnos.solicitarIntercambio(this.day.fecha,this.selected,this.reason).subscribe({next:()=>{this.sending.set(false);this.alerts.successToast('Solicitud enviada','El horario cambiará únicamente si tu compañero la acepta.');this.close();},error:e=>{this.sending.set(false);this.alerts.errorToast('No se pudo enviar',e?.error?.message||'Inténtalo nuevamente.');}});}
 time(v:string|null){if(!v)return'—';const[h,m]=v.split(':').map(Number);return`${h%12||12}:${String(m).padStart(2,'0')} ${h>=12?'p. m.':'a. m.'}`;}dateLabel(v:string){return new Intl.DateTimeFormat('es-CO',{day:'numeric',month:'long',timeZone:'UTC'}).format(new Date(v+'T00:00:00Z'));}
}
