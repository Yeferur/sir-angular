import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, computed, inject, signal, effect } from '@angular/core';
import { RouterOutlet, Router, Event as RouterEvent, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { SirAlertsHostComponent } from './components/alerts/alerts-host';
import {SirDrawerHostComponent} from "./components/drawer/drawer-host";
import { CommonModule } from '@angular/common';
import { AuthService } from './services/Login/login-service';
import { WebSocketService } from './services/WebSocket/web-socket';
import { PermisosService } from './services/Permisos/permisos.service';
import { Subject, takeUntil, distinctUntilChanged } from 'rxjs';
import { LayoutComponent } from './layout/layout';
import { SirAlertService } from './services/Alertas/alert.service';
import { TopbarTransitionService } from './components/login/topbar-transition.service';
import { AppVersionService } from './services/AppUpdates/app-version.service';
import { HasUnsavedChanges, confirmLeavingUnsavedChanges } from './guards/unsaved-changes.guard';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, LayoutComponent, SirAlertsHostComponent, SirDrawerHostComponent, CommonModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App implements OnInit, OnDestroy {
  @ViewChild(RouterOutlet) private activeOutlet?: RouterOutlet;
  loggedIn = false;
  publicAuthRoute = false;
  routeTransitioning = signal(false);

  /**
   * Controla qué rama del template se muestra. Deliberadamente
   * separado de `loggedIn`: la coreografía isla↔login (ver
   * TopbarTransitionService) necesita que la animación de expansión
   * o colapso termine ANTES de que Angular desmonte/monte
   * Layout/Login, así que este signal solo cambia cuando la
   * transición avisa que terminó (o, en el arranque en frío / 
   * sin animación posible, por un fallback de sincronización).
   */
  viewLoggedIn = signal(false);
  shellEntering = signal(false);

  private transition = inject(TopbarTransitionService);
  readonly sessionTransitioning = computed(() => {
    const phase = this.transition.phase();
    return phase === 'expanding' || phase === 'collapsing';
  });
  private viewGateBooted = false;
  private pendingViewSyncTimer: any;
  private shellEntryTimer: any;

  private readonly shellPhaseEffect = effect(() => {
    const phase = this.transition.phase();
    this.syncSessionScrollLock();
    if (phase === 'app') {
      this.viewLoggedIn.set(true);
      this.shellEntering.set(true);
      clearTimeout(this.shellEntryTimer);
      this.shellEntryTimer = setTimeout(() => this.shellEntering.set(false), 650);
      if (this.loggedIn) this.startVersionCheck();
    }
    if (phase === 'login') this.viewLoggedIn.set(false);
    this.cdr.markForCheck();
  });

  private destroy$ = new Subject<void>();
  private wsStarted = false;

  private isAdminForceLogoutEvent(msg: any): boolean {
    const type = String(msg?.type || '');
    const reason = String(msg?.reason || '');
    return type === 'forceLogout' || type === 'force-logout' || type === 'adminForceLogout' || reason === 'admin_force_logout';
  }

  private isSelfLogoutAllSessionsEvent(msg: any): boolean {
    const type = String(msg?.type || '');
    const reason = String(msg?.reason || '');
    return type === 'selfLogoutAllSessions' || reason === 'self_logout_all_sessions';
  }

  private isCurrentSessionLogoutEvent(msg: any): boolean {
    const type = String(msg?.type || '');
    const reason = String(msg?.reason || '');
    return type === 'logout' || type === 'selfLogoutCurrentSession' || reason === 'self_logout_current_session';
  }

  constructor(
    public auth: AuthService,
    private ws: WebSocketService,
    private permisosService: PermisosService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private alerts: SirAlertService,
    private appVersion: AppVersionService
  ) {}

  private async mayReloadForUpdate(): Promise<boolean> {
    const component = this.activeOutlet?.isActivated
      ? this.activeOutlet.component as Partial<HasUnsavedChanges>
      : null;
    return confirmLeavingUnsavedChanges(component, this.alerts);
  }

  private startVersionCheck(): void {
    const userId = this.auth.getUser()?.id;
    if (userId != null) this.appVersion.start(userId, () => this.mayReloadForUpdate());
  }

  private isPublicAuthRoute(url: string): boolean {
    const normalizedUrl = url || '';
    return normalizedUrl.startsWith('/reset-password');
  }

  private syncSessionScrollLock(): void {
    if (typeof document === 'undefined') return;
    const phase = this.transition.phase();
    const shouldLock = !this.publicAuthRoute && phase !== 'app';
    document.documentElement.classList.toggle('sir-session-scroll-lock', shouldLock);
    document.body.classList.toggle('sir-session-scroll-lock', shouldLock);
  }

  private scheduleViewSync(target: boolean, graceMs: number): void {
    this.viewGateBooted = true;
    clearTimeout(this.pendingViewSyncTimer);

    this.pendingViewSyncTimer = setTimeout(() => {
      const phase = this.transition.phase();

      // Tras el arranque, la fase de TopbarTransitionService es la autoridad.
      // No montamos el shell privado por un simple cambio de auth mientras el
      // topbar continúa en `collapsing`, porque eso crea scroll detrás del
      // fullscreen y compite con la animación de bienvenida.
      if (target) {
        if (phase !== 'app') return;
        this.viewLoggedIn.set(true);
      } else {
        if (phase !== 'login') return;
        this.viewLoggedIn.set(false);
      }
      this.cdr.markForCheck();
    }, graceMs);
  }

  private syncShellForUrl(url: string) {
    this.publicAuthRoute = this.isPublicAuthRoute(url);
    this.syncSessionScrollLock();

    if (!this.loggedIn && this.publicAuthRoute) {
      this.alerts.closeModal();
    }

    this.cdr.markForCheck();
  }

  ngOnInit() {
    this.syncShellForUrl(this.router.url);

    // En una recarga con token vigente, el primer frame ya debe usar la
    // geometría privada. No hay una transición de login que reproducir.
    if (this.auth.getToken()) {
      this.loggedIn = true;
      this.viewGateBooted = true;
      this.viewLoggedIn.set(true);
      this.transition.markAppReady();
    }

    // Arranque en frío (carga directa / refresh): nadie va a llamar
    // completeLoginView/completeLogoutView porque no hubo un logout/login
    // interactivo que animar. A los 60ms, si el gate sigue sin "armar",
    // sincroniza viewLoggedIn directo con el loggedIn real y lo marca
    // como arrancado — de ahí en más todo cambio de loggedIn pasa por
    // la transición (ver scheduleViewSync).
    setTimeout(() => {
      if (this.viewGateBooted) return;
      this.viewGateBooted = true;
      this.viewLoggedIn.set(this.loggedIn);
      this.cdr.markForCheck();
    }, 60);

    this.router.events
      .pipe(takeUntil(this.destroy$))
      .subscribe((event: RouterEvent) => {
        if (event instanceof NavigationStart) {
          queueMicrotask(() => this.routeTransitioning.set(true));
          this.syncShellForUrl(event.url);
        } else if (
          event instanceof NavigationEnd ||
          event instanceof NavigationCancel ||
          event instanceof NavigationError
        ) {
          const url = event instanceof NavigationEnd ? event.urlAfterRedirects : this.router.url;
          queueMicrotask(() => this.routeTransitioning.set(false));
          this.syncShellForUrl(url);

          this.cdr.markForCheck();
        }
      });

    this.permisosService.cargarPermisosDesdeLocalStorage();

    this.ws.systemEvents$
      .pipe(takeUntil(this.destroy$))
      .subscribe((msg: any) => {
        if (this.isAdminForceLogoutEvent(msg)) {
          clearTimeout(this.pendingViewSyncTimer);
          this.viewLoggedIn.set(false);
          this.ws.disconnect();
          this.auth.clearLocalSession();
          this.permisosService.limpiarPermisos();
          this.wsStarted = false;
          this.alerts.showAlert({
            type: 'warning',
            title: 'Sesión cerrada',
            message: 'Tu sesión fue cerrada por un administrador.',
            dismissible: false,
            buttons: [
              { text: 'Entendido', style: 'primary', onClick: () => this.alerts.closeModal() },
            ],
          });
          this.cdr.markForCheck();

          return;
        }

        if (this.isSelfLogoutAllSessionsEvent(msg)) {
          clearTimeout(this.pendingViewSyncTimer);
          this.viewLoggedIn.set(false);
          this.ws.disconnect();
          this.auth.clearLocalSession();
          this.permisosService.limpiarPermisos();
          this.wsStarted = false;
          this.alerts.showAlert({
            type: 'info',
            title: 'Sesión cerrada',
            message: 'Tu sesión fue cerrada en todos tus dispositivos.',
            dismissible: false,
            buttons: [
              { text: 'Entendido', style: 'primary', onClick: () => this.alerts.closeModal() },
            ],
          });
          this.cdr.markForCheck();

          return;
        }

        if (this.isCurrentSessionLogoutEvent(msg)) {
          clearTimeout(this.pendingViewSyncTimer);
          this.viewLoggedIn.set(false);
          this.cdr.markForCheck();
          this.ws.disconnect();
          this.auth.clearLocalSession();
          this.permisosService.limpiarPermisos();
          this.wsStarted = false;
          this.cdr.markForCheck();
          return;
        }
      });

    this.auth.isLoggedIn()
      .pipe(distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((logged) => {
        this.loggedIn = logged;
        this.cdr.markForCheck();

        if (!this.viewGateBooted) {
          this.scheduleViewSync(logged, 60);
        } else {
          const phase = this.transition.phase();
          if (logged && phase === 'app') this.viewLoggedIn.set(true);
          if (!logged && phase === 'login') this.viewLoggedIn.set(false);
        }

        if (logged) {
          if (this.transition.phase() === 'app') this.startVersionCheck();
          const token = this.auth.getToken();
          if (token && !this.wsStarted) {
            this.ws.connect(token);
            this.wsStarted = true;
          }
          this.permisosService.cargarPermisosDesdeLocalStorage();
        } else {
          this.appVersion.stop();
          if (this.transition.phase() === 'app') {
            this.transition.markLoginReady();
          }
          this.ws.disconnect();
          this.permisosService.limpiarPermisos();
          this.wsStarted = false;
          this.cdr.markForCheck();
        }
      });
  }

  ngOnDestroy() {
    this.appVersion.stop();
    this.destroy$.next();
    this.destroy$.complete();
    clearTimeout(this.pendingViewSyncTimer);
    clearTimeout(this.shellEntryTimer);
    if (typeof document !== 'undefined') {
      document.documentElement.classList.remove('sir-session-scroll-lock');
      document.body.classList.remove('sir-session-scroll-lock');
    }
    this.ws.disconnect();
  }
}
